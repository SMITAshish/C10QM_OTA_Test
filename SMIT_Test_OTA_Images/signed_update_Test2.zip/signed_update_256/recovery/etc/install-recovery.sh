#!/system/bin/sh
if ! applypatch -c MTD:recovery:5820416:fcaa5a3f3c830469f757d8dbb3c2b4597e2db689; then
  applypatch  MTD:boot:5820416:fcaa5a3f3c830469f757d8dbb3c2b4597e2db689 MTD:recovery fcaa5a3f3c830469f757d8dbb3c2b4597e2db689 5820416 fcaa5a3f3c830469f757d8dbb3c2b4597e2db689:/system/recovery-from-boot.p && log -t recovery "Installing new recovery image: succeeded" || log -t recovery "Installing new recovery image: failed"
else
  log -t recovery "Recovery image already installed"
fi
