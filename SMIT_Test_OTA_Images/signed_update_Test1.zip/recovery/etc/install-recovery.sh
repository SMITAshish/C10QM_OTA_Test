#!/system/bin/sh
if ! applypatch -c MTD:recovery:5822464:da71f71216a09e538d35f7b256e6c24589f9f460; then
  applypatch  MTD:boot:5822464:da71f71216a09e538d35f7b256e6c24589f9f460 MTD:recovery da71f71216a09e538d35f7b256e6c24589f9f460 5822464 da71f71216a09e538d35f7b256e6c24589f9f460:/system/recovery-from-boot.p && log -t recovery "Installing new recovery image: succeeded" || log -t recovery "Installing new recovery image: failed"
else
  log -t recovery "Recovery image already installed"
fi
