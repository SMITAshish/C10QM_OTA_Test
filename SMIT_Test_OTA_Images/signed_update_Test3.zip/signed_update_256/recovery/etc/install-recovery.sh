#!/system/bin/sh
if ! applypatch -c MTD:recovery:5820416:33d610bc51e7348e591f523abb63c349bb34d8e2; then
  applypatch  MTD:boot:5820416:33d610bc51e7348e591f523abb63c349bb34d8e2 MTD:recovery 33d610bc51e7348e591f523abb63c349bb34d8e2 5820416 33d610bc51e7348e591f523abb63c349bb34d8e2:/system/recovery-from-boot.p && log -t recovery "Installing new recovery image: succeeded" || log -t recovery "Installing new recovery image: failed"
else
  log -t recovery "Recovery image already installed"
fi
