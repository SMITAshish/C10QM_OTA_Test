#!/system/bin/sh
if ! applypatch -c MTD:recovery:5756928:a9d0f56c948c622b23a2c29e59432784202c6ceb; then
  applypatch  MTD:boot:5756928:a9d0f56c948c622b23a2c29e59432784202c6ceb MTD:recovery a9d0f56c948c622b23a2c29e59432784202c6ceb 5756928 a9d0f56c948c622b23a2c29e59432784202c6ceb:/system/recovery-from-boot.p && log -t recovery "Installing new recovery image: succeeded" || log -t recovery "Installing new recovery image: failed"
else
  log -t recovery "Recovery image already installed"
fi
