#!/system/bin/sh
if ! applypatch -c MTD:recovery:5822464:fe41de65d145551a04530db1ad04ebcbc7606080; then
  applypatch  MTD:boot:5822464:fe41de65d145551a04530db1ad04ebcbc7606080 MTD:recovery fe41de65d145551a04530db1ad04ebcbc7606080 5822464 fe41de65d145551a04530db1ad04ebcbc7606080:/system/recovery-from-boot.p && log -t recovery "Installing new recovery image: succeeded" || log -t recovery "Installing new recovery image: failed"
else
  log -t recovery "Recovery image already installed"
fi
